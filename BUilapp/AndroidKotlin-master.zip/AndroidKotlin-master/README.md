# Distance Converter using Kotlin

Build Your First Android App (Project-Centered Course)
by CentraleSupélec

Week 2 App from a coursera course using Kotlin instead of Java. 

https://www.coursera.org/learn/android-app/home/welcome
