package com.example.kmmiles;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buttonConvMilestoKm = (Button)findViewById(R.id.buttonMilestoKm);
        buttonConvMilestoKm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textBoxMiles= (EditText) findViewById(R.id.editTextMiles);
                EditText textBoxKm= (EditText) findViewById(R.id.editTextKm);
                double vmiles;
                if(textBoxMiles.getText().toString() == "" )
                vmiles=0;
                else
                vmiles= Double.valueOf(textBoxMiles.getText().toString());
                vmiles= vmiles/0.62137;
                DecimalFormat val= new DecimalFormat("##.##");
                textBoxKm.setText(val.format(vmiles));
            }
        });
        Button buttonConvKmtoMiles = (Button)findViewById(R.id.buttonKmtoMiles);
        buttonConvKmtoMiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText textBoxMiles= (EditText) findViewById(R.id.editTextMiles);
                EditText textBoxKm= (EditText) findViewById(R.id.editTextKm);
                double vkm;
                if(textBoxKm.getText().toString() == "" )
                vkm=0;
                else
                    vkm= Double.valueOf(textBoxKm.getText().toString());
                vkm=vkm*0.62137;
                DecimalFormat val= new DecimalFormat("##.##");
                textBoxMiles.setText(val.format(vkm));
            }
        });

    }
}
