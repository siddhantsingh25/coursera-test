package smogblog.umbc.smogblogapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.widget.NumberPicker;



public class MainActivity extends AppCompatActivity {

    NumberPicker dates;
    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dates = (NumberPicker)findViewById(R.id.numberPicker);
        webView = (WebView) findViewById(R.id.webView);
        String[] datesStrings = {
                "March 6, 2019",
                "March 5, 2019",
                "January 30, 2019"
        };
        dates.setDisplayedValues(datesStrings);
        dates.setMinValue(0);
        dates.setMaxValue(datesStrings.length-1);
    }
    public void navigate(View v){
        int choice = dates.getValue();
        if(choice==0)
            webView.loadUrl("file:///android_asset/SmogBlogArticleMarch.html");
        else if (choice == 1)
            webView.loadUrl("file:///android_asset/SmogBlogArticleMarch.html");
        else if (choice == 2)
            webView.loadUrl("file:///android_asset/SmogBlogArticleJanuary.html");
    }
}
